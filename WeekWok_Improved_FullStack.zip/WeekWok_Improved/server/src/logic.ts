export type Requirement = { name: string; quantity: number; unit: string };
export type Stock = { name: string; quantity: number; unit: string };
export type GroceryNeed = Requirement & { deficit: number };

/** Consolidates recipe needs by ingredient and calculates deficits against pantry stock.
 * Recipe quantities and stock must use the same normalized unit (g, ml, or pcs).
 */
export function calculateGroceryNeeds(
  requirements: Requirement[],
  stock: Stock[]
): GroceryNeed[] {
  const totals = new Map<string, Requirement>();
  for (const item of requirements) {
    const key = item.name.trim().toLocaleLowerCase();
    if (!key || !Number.isFinite(item.quantity) || item.quantity < 0) continue;
    const existing = totals.get(key);
    if (existing && existing.unit !== item.unit) {
      throw new Error(`Unit mismatch for ${item.name}: ${existing.unit} and ${item.unit}`);
    }
    totals.set(key, {
      name: existing?.name ?? item.name.trim(),
      quantity: (existing?.quantity ?? 0) + item.quantity,
      unit: item.unit
    });
  }
  const stockMap = new Map(stock.map(x => [x.name.trim().toLocaleLowerCase(), x]));
  return [...totals.values()].map(item => {
    const available = stockMap.get(item.name.toLocaleLowerCase());
    if (available && available.unit !== item.unit) {
      throw new Error(`Unit mismatch for ${item.name}: pantry uses ${available.unit}, recipe uses ${item.unit}`);
    }
    const deficit = Math.max(0, item.quantity - (available?.quantity ?? 0));
    return { ...item, deficit };
  }).filter(x => x.deficit > 0);
}
