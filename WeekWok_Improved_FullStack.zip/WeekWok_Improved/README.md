# WeekWok — Pantry Planner (Improved Full-Stack Build)

A full-stack rebuild of the supplied WeekWok prototype. This version directly addresses the evaluation report's main gaps: React + TypeScript frontend, Node.js + Express REST API, SQLite persistence, modular code, input validation, and automated tests.

## Requirements
- Node.js 20 or later (Node 22 LTS recommended)
- npm 10+
- Windows, macOS, or Linux

## Run on Windows (PowerShell)
1. Extract the ZIP file.
2. Open the extracted `WeekWok_Improved` folder in VS Code.
3. Open Terminal in that folder.
4. Run:

   ```powershell
   npm install
   npm run dev
   ```

5. Open the frontend at **http://localhost:5173**.
6. The Express API runs at **http://localhost:4000/api/health**.

Stop both servers with `Ctrl + C`.

## Production build
```bash
npm install
npm run build
npm start
```
The backend build is generated in `server/dist`; the frontend build is generated in `client/dist`. For a production deployment, serve the `client/dist` static files from a web server (or configure Express static hosting) and set the API URL/proxy for your deployment.

## Automated tests and checks
```bash
npm test
npm run typecheck
```
Tests cover ingredient aggregation, stock deficit calculation, sufficient stock, and incompatible units.

## Features
- Overview dashboard with live database-backed metrics
- Monday–Sunday planner with breakfast, lunch, and dinner slots
- HTML5 drag-and-drop recipe cards onto planner slots, plus quick-select assignment and removal; replacing/removing a slot recalculates needs
- Pantry inventory with stock adjustment, thresholds, expiry dates, and low-stock status
- Recipe catalog with 15 seeded family recipes and ingredient measurements
- Add your own recipes with ingredient validation
- Consolidated grocery list generated from all scheduled meals
- Manual grocery list entries and copy-to-clipboard sharing
- Estimated grocery cost
- Responsive mobile layout

## Architecture
- `client/`: React 18 + TypeScript + Vite UI
- `server/`: Express + TypeScript REST API
- `server/src/db.ts`: SQLite schema and starter dataset
- `server/src/logic.ts`: pure inventory/grocery calculation logic
- `server/test/`: automated unit tests

## Inventory calculation model
This implementation uses **dynamic reservation / requirement accounting** rather than permanently subtracting pantry stock every time a meal is added. The server sums all ingredients required by scheduled meals, compares those totals to pantry stock, and adds only the deficit to the grocery list:

`Deficit = max(0, TotalRecipeRequirement - PantryStock)`

This prevents double deductions when the user edits or removes a meal. All quantities in the recipe catalogue and seeded pantry are stored in normalized grams, millilitres, or pieces. The API validates input and rejects incompatible units rather than silently combining them.

## API overview
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET | `/api/dashboard` | Dashboard, pantry, recipes, plan and grocery data |
| GET | `/api/pantry` | List pantry items |
| POST/PATCH/DELETE | `/api/pantry` | Add/update/remove pantry items |
| GET/POST | `/api/recipes` | List and add recipes |
| GET | `/api/plan` | List scheduled meals |
| PUT/DELETE | `/api/plan/:day/:meal` | Assign, replace or remove a meal |
| POST/PATCH/DELETE | `/api/grocery` | Manage manual grocery entries |

## Important notes
- SQLite database is created automatically at `server/data/weekwok.sqlite` on first server start and seeded with 20 pantry staples, 15 recipes, and a sample weekly plan.
- Keep the `server/data` folder writable.
- This is an academic prototype, not a deployed multi-family production service. Multi-user authentication and real-time family sync are not implemented; the original problem brief lists family sync as a stretch feature.
- Grocery prices are estimates for demonstration and should be updated with local store prices.
