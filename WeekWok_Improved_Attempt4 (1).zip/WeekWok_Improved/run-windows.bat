@echo off
title WeekWok Pantry Planner
echo ========================================
echo   WeekWok - Pantry Planner
echo ========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 20 or later from https://nodejs.org/
  pause
  exit /b 1
)
echo Installing project dependencies...
call npm install
if errorlevel 1 (
  echo Dependency installation failed. Check your internet connection and Node.js version.
  pause
  exit /b 1
)
echo Starting frontend and backend...
call npm run dev
pause
