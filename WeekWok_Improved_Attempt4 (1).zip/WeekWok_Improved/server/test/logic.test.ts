import test from "node:test";
import assert from "node:assert/strict";
import { calculateGroceryNeeds, normalizeQuantity } from "../src/logic.js";

test("consolidates repeated ingredients and returns only the deficit", () => {
 const result=calculateGroceryNeeds(
  [{name:"Paneer",quantity:200,unit:"g"},{name:"Paneer",quantity:200,unit:"g"},{name:"Tomatoes",quantity:100,unit:"g"}],
  [{name:"Paneer",quantity:200,unit:"g"},{name:"Tomatoes",quantity:300,unit:"g"}]
 );
 assert.deepEqual(result,[{name:"Paneer",quantity:400,unit:"g",deficit:200}]);
});
test("returns the full requirement when pantry stock is missing",()=>{
 assert.deepEqual(calculateGroceryNeeds([{name:"Rice",quantity:250,unit:"g"}],[]),[{name:"Rice",quantity:250,unit:"g",deficit:250}]);
});
test("does not create a deficit when stock covers demand",()=>{
 assert.deepEqual(calculateGroceryNeeds([{name:"Milk",quantity:500,unit:"ml"}],[{name:"Milk",quantity:900,unit:"ml"}]),[]);
});
test("rejects incompatible units for the same ingredient",()=>{
 assert.throws(()=>calculateGroceryNeeds([{name:"Oil",quantity:100,unit:"ml"},{name:"Oil",quantity:1,unit:"g"}],[]),/Unit mismatch/);
});

test("normalizes kilograms and litres into canonical units",()=>{
 assert.deepEqual(normalizeQuantity(1.5,"kg"),{quantity:1500,unit:"g"});
 assert.deepEqual(normalizeQuantity(2,"l"),{quantity:2000,unit:"ml"});
});
test("aggregates mixed compatible units instead of rejecting them",()=>{
 const result=calculateGroceryNeeds([{name:"Rice",quantity:500,unit:"g"},{name:"Rice",quantity:1,unit:"kg"}],[{name:"Rice",quantity:800,unit:"g"}]);
 assert.deepEqual(result,[{name:"Rice",quantity:1500,unit:"g",deficit:700}]);
});
