import Database from "better-sqlite3";
import path from "node:path";
import fs from "node:fs";

const dataDir = path.resolve(process.cwd(), "data");
fs.mkdirSync(dataDir, { recursive: true });
export const db = new Database(path.join(dataDir, "weekwok.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS family_members (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS pantry_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
 quantity REAL NOT NULL DEFAULT 0 CHECK(quantity >= 0), unit TEXT NOT NULL,
 threshold REAL NOT NULL DEFAULT 0 CHECK(threshold >= 0), expiry_date TEXT,
 price_per_unit REAL NOT NULL DEFAULT 0 CHECK(price_per_unit >= 0), emoji TEXT NOT NULL DEFAULT '🥬'
);
CREATE TABLE IF NOT EXISTS recipes (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
 emoji TEXT NOT NULL DEFAULT '🍲', prep_minutes INTEGER NOT NULL DEFAULT 20,
 servings INTEGER NOT NULL DEFAULT 4, instructions TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS recipe_ingredients (
 id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
 ingredient_name TEXT NOT NULL, quantity REAL NOT NULL CHECK(quantity >= 0), unit TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS meal_schedules (
 id INTEGER PRIMARY KEY AUTOINCREMENT, day_index INTEGER NOT NULL CHECK(day_index BETWEEN 0 AND 6),
 meal_type TEXT NOT NULL CHECK(meal_type IN ('breakfast','lunch','dinner')),
 recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
 UNIQUE(day_index, meal_type)
);
CREATE TABLE IF NOT EXISTS grocery_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL,
 unit TEXT NOT NULL, checked INTEGER NOT NULL DEFAULT 0, source TEXT NOT NULL DEFAULT 'manual',
 price_estimate REAL NOT NULL DEFAULT 0
);
`);

const pantryCount = (db.prepare("SELECT COUNT(*) AS n FROM pantry_items").get() as {n:number}).n;
if (pantryCount === 0) {
 const insert = db.prepare(`INSERT INTO pantry_items(name,quantity,unit,threshold,expiry_date,price_per_unit,emoji) VALUES(?,?,?,?,?,?,?)`);
 const rows = [
  ["Rice",1200,"g",300,"2026-12-18",0.05,"🍚"],["Basmati Rice",200,"g",250,"2027-02-10",0.07,"🍚"],
  ["Cooking Oil",750,"ml",200,"2027-04-15",0.12,"🫗"],["Onions",500,"g",200,"2026-12-02",0.03,"🧅"],
  ["Eggs",6,"pcs",4,"2026-11-30",8,"🥚"],["Paneer",200,"g",250,"2026-12-01",0.45,"🧀"],
  ["Tomatoes",300,"g",250,"2026-12-01",0.025,"🍅"],["Potatoes",800,"g",250,"2026-12-12",0.025,"🥔"],
  ["Wheat Flour",1000,"g",300,"2027-01-20",0.04,"🌾"],["Toor Dal",500,"g",200,"2027-03-01",0.14,"🫘"],
  ["Rava",400,"g",150,"2027-02-01",0.06,"🌾"],["Chickpeas",300,"g",200,"2027-03-15",0.10,"🫘"],
  ["Curd",250,"g",200,"2026-11-30",0.08,"🥛"],["Mixed Vegetables",250,"g",200,"2026-12-01",0.08,"🥦"],
  ["Dosa Batter",500,"g",200,"2026-12-01",0.05,"🥣"],["Poha",250,"g",100,"2027-02-01",0.06,"🍚"],
  ["Peanuts",150,"g",80,"2027-04-01",0.12,"🥜"],["Green Peas",100,"g",150,"2026-12-02",0.035,"🟢"],
  ["Milk",1000,"ml",300,"2026-11-30",0.07,"🥛"],["Sugar",500,"g",150,"2027-06-01",0.045,"🍬"]
 ];
 const tx = db.transaction(() => rows.forEach(r => insert.run(...r)));
 tx();
}
const recipeCount = (db.prepare("SELECT COUNT(*) AS n FROM recipes").get() as {n:number}).n;
if (recipeCount === 0) {
 const recipes = [
  ["Vegetable Pulao","lunch","🍚",30,4,"Cook rice with vegetables and spices." , [["Basmati Rice",300,"g"],["Mixed Vegetables",200,"g"],["Cooking Oil",20,"ml"],["Onions",100,"g"],["Green Peas",80,"g"]]],
  ["Paneer Butter Masala","dinner","🍛",35,4,"Simmer paneer in a tomato-onion gravy." , [["Paneer",400,"g"],["Tomatoes",250,"g"],["Onions",100,"g"],["Cooking Oil",20,"ml"]]],
  ["Vegetable Upma","breakfast","🥣",20,3,"Roast rava, then cook with vegetables and seasoning." , [["Rava",200,"g"],["Onions",60,"g"],["Cooking Oil",15,"ml"]]],
  ["Chana Masala","dinner","🫘",40,4,"Cook chickpeas in a spiced tomato gravy." , [["Chickpeas",250,"g"],["Tomatoes",150,"g"],["Onions",100,"g"]]],
  ["Masala Dosa","breakfast","🥞",25,3,"Fill dosa with seasoned potato masala." , [["Dosa Batter",400,"g"],["Potatoes",200,"g"],["Onions",50,"g"]]],
  ["Dal Tadka","lunch","🍲",30,4,"Pressure cook dal and finish with a tempering." , [["Toor Dal",200,"g"],["Tomatoes",100,"g"],["Onions",50,"g"],["Cooking Oil",15,"ml"]]],
  ["Curd Rice","lunch","🍚",15,2,"Mix cooked rice and curd; temper to finish." , [["Rice",200,"g"],["Curd",150,"g"]]],
  ["Chapati & Aloo Curry","dinner","🫓",35,4,"Serve soft chapatis with potato curry." , [["Wheat Flour",250,"g"],["Potatoes",250,"g"],["Onions",80,"g"]]],
  ["Poha","breakfast","🥘",15,2,"Rinse poha and toss with onions and peanuts." , [["Poha",180,"g"],["Onions",60,"g"],["Peanuts",30,"g"]]],
  ["Egg Bhurji","breakfast","🍳",15,2,"Scramble eggs with onions and spices." , [["Eggs",2,"pcs"],["Onions",50,"g"],["Cooking Oil",10,"ml"]]],
  ["Tomato Pappu","lunch","🍅",35,4,"Cook dal with tomatoes until soft." , [["Toor Dal",180,"g"],["Tomatoes",200,"g"],["Cooking Oil",10,"ml"]]],
  ["Aloo Paratha","breakfast","🫓",30,3,"Stuff wheat dough with spiced mashed potato." , [["Wheat Flour",220,"g"],["Potatoes",180,"g"],["Cooking Oil",10,"ml"]]],
  ["Peas Pulao","lunch","🍚",25,3,"Cook rice with green peas and spices." , [["Rice",250,"g"],["Green Peas",150,"g"],["Cooking Oil",15,"ml"]]],
  ["Milk Oats","breakfast","🥣",10,2,"Simmer oats in milk." , [["Milk",300,"ml"]]],
  ["Chana Salad","dinner","🥗",15,2,"Mix cooked chickpeas, tomato and onion." , [["Chickpeas",150,"g"],["Tomatoes",100,"g"],["Onions",50,"g"]]]
 ];
 const tx = db.transaction(() => {
  for (const r of recipes) {
   const info = db.prepare("INSERT INTO recipes(name,category,emoji,prep_minutes,servings,instructions) VALUES(?,?,?,?,?,?)").run(...r.slice(0,6) as [string,string,string,number,number,string]);
   const add = db.prepare("INSERT INTO recipe_ingredients(recipe_id,ingredient_name,quantity,unit) VALUES(?,?,?,?)");
   for (const ing of r[6]) add.run(info.lastInsertRowid,...ing);
  }
 });
 tx();
}
const scheduleCount = (db.prepare("SELECT COUNT(*) AS n FROM meal_schedules").get() as {n:number}).n;
if (scheduleCount === 0) {
 const slots: [number,string,number][] = [[0,"breakfast",3],[0,"lunch",6],[0,"dinner",4],[1,"breakfast",5],[1,"lunch",7],[1,"dinner",2],[2,"breakfast",3],[2,"lunch",1],[3,"breakfast",5],[3,"dinner",8],[4,"lunch",6],[4,"dinner",2]];
 const add = db.prepare("INSERT INTO meal_schedules(day_index,meal_type,recipe_id) VALUES(?,?,?)");
 const tx = db.transaction(() => slots.forEach(s => add.run(...s)));
 tx();
}

// Performance indexes for the most common planner and ingredient lookups.
db.exec(`
CREATE INDEX IF NOT EXISTS idx_schedule_day_meal ON meal_schedules(day_index, meal_type);
CREATE INDEX IF NOT EXISTS idx_recipe_ingredients_recipe ON recipe_ingredients(recipe_id);
CREATE INDEX IF NOT EXISTS idx_grocery_source_checked ON grocery_items(source, checked);
CREATE INDEX IF NOT EXISTS idx_pantry_expiry ON pantry_items(expiry_date);
`);
