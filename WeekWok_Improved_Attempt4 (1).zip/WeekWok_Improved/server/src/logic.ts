export type Requirement = { name: string; quantity: number; unit: string };
export type Stock = { name: string; quantity: number; unit: string };
export type GroceryNeed = Requirement & { deficit: number };

/** Consolidates recipe needs by ingredient and calculates deficits against pantry stock.
 * Recipe quantities and stock must use the same normalized unit (g, ml, or pcs).
 */
export function calculateGroceryNeeds(
  requirements: Requirement[],
  stock: Stock[]
): GroceryNeed[] {
  const totals = new Map<string, Requirement>();
  for (const item of requirements) {
    const key = item.name.trim().toLocaleLowerCase();
    if (!key || !Number.isFinite(item.quantity) || item.quantity < 0) continue;
    const existing = totals.get(key);
    const normalized = normalizeQuantity(item.quantity, item.unit);
    if (existing && existing.unit !== normalized.unit) {
      throw new Error(`Unit mismatch for ${item.name}: ${existing.unit} and ${normalized.unit}`);
    }
    totals.set(key, {
      name: existing?.name ?? item.name.trim(),
      quantity: (existing?.quantity ?? 0) + normalized.quantity,
      unit: normalized.unit
    });
  }
  const stockMap = new Map(stock.map(x => { const n = normalizeQuantity(x.quantity, x.unit); return [x.name.trim().toLocaleLowerCase(), { ...x, quantity: n.quantity, unit: n.unit }]; }));
  return [...totals.values()].map(item => {
    const available = stockMap.get(item.name.toLocaleLowerCase());
    if (available && available.unit !== item.unit) {
      throw new Error(`Unit mismatch for ${item.name}: pantry uses ${available.unit}, recipe uses ${item.unit}`);
    }
    const deficit = Math.max(0, item.quantity - (available?.quantity ?? 0));
    return { ...item, deficit };
  }).filter(x => x.deficit > 0);
}

/** Convert mass and volume to canonical base units before aggregation. */
export function normalizeQuantity(quantity: number, unit: string): { quantity: number; unit: string } {
  const conversions: Record<string, { factor: number; unit: string }> = {
    kg: { factor: 1000, unit: "g" }, g: { factor: 1, unit: "g" },
    l: { factor: 1000, unit: "ml" }, ml: { factor: 1, unit: "ml" },
    pcs: { factor: 1, unit: "pcs" }
  };
  const conversion = conversions[unit.toLowerCase()];
  if (!conversion) throw new Error(`Unsupported unit: ${unit}`);
  return { quantity: quantity * conversion.factor, unit: conversion.unit };
}
