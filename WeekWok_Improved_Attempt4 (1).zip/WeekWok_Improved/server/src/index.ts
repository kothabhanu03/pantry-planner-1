import "dotenv/config";
import express from "express";
import crypto from "node:crypto";
import cors from "cors";
import { z } from "zod";
import { db } from "./db.js";
import { calculateGroceryNeeds } from "./logic.js";

const app = express();
app.use(cors());
app.use(express.json({ limit: "100kb" }));
const PORT = Number(process.env.PORT || 4000);
const days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
const asyncRoute = (fn: express.RequestHandler): express.RequestHandler => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);

function plannerData() {
 const pantry = db.prepare("SELECT * FROM pantry_items ORDER BY name").all();
 const recipes = db.prepare(`SELECT r.*, COALESCE(json_group_array(json_object('name',i.ingredient_name,'quantity',i.quantity,'unit',i.unit)), '[]') AS ingredients
   FROM recipes r LEFT JOIN recipe_ingredients i ON i.recipe_id=r.id GROUP BY r.id ORDER BY r.name`).all().map((r:any) => ({...r, ingredients: JSON.parse(r.ingredients).filter((x:any)=>x.name)}));
 const plan = db.prepare(`SELECT m.id,m.day_index,m.meal_type,m.recipe_id,r.name,r.emoji,r.prep_minutes
   FROM meal_schedules m JOIN recipes r ON r.id=m.recipe_id ORDER BY m.day_index`).all();
 const requirements:any[] = [];
 for (const slot of plan as any[]) {
  const ingredients = db.prepare("SELECT ingredient_name AS name,quantity,unit FROM recipe_ingredients WHERE recipe_id=?").all(slot.recipe_id) as any[];
  requirements.push(...ingredients);
 }
 const needs = calculateGroceryNeeds(requirements, (pantry as any[]).map(p=>({name:p.name,quantity:p.quantity,unit:p.unit})));
 const autoItems = needs.map(n => {
  const p = (pantry as any[]).find(x=>x.name.toLowerCase()===n.name.toLowerCase());
  return {...n, id:`auto-${n.name}`, checked:0, source:"auto", price_estimate: Math.round(n.deficit*(p?.price_per_unit||0)*100)/100};
 });
 const manual = db.prepare("SELECT * FROM grocery_items WHERE source='manual' ORDER BY id DESC").all();
 const expiring = (pantry as any[]).filter(p => {
  if (!p.expiry_date) return false;
  const delta = (Date.parse(p.expiry_date+"T00:00:00Z")-Date.now())/86400000;
  return delta >= -1 && delta <= 3;
 });
 return {days, pantry, recipes, plan, grocery:[...autoItems,...manual], needs, expiring};
}
// Minimal HS256 session tokens and scrypt password hashes (no hard-coded signing secret).
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString("hex");
const hashPassword = (password: string, salt = crypto.randomBytes(16).toString("hex")) => `${salt}:${crypto.scryptSync(password, salt, 64).toString("hex")}`;
const verifyPassword = (password: string, stored: string) => { const [salt, hash] = stored.split(":"); if (!salt || !hash) return false; const actual = crypto.scryptSync(password, salt, 64); const expected = Buffer.from(hash, "hex"); return actual.length === expected.length && crypto.timingSafeEqual(actual, expected); };
const signToken = (payload: object) => { const enc = (v: unknown) => Buffer.from(JSON.stringify(v)).toString("base64url"); const head = enc({alg:"HS256",typ:"JWT"}); const body = enc({...payload,exp:Math.floor(Date.now()/1000)+60*60*12}); const data = `${head}.${body}`; return `${data}.${crypto.createHmac("sha256",JWT_SECRET).update(data).digest("base64url")}`; };
const verifyToken = (token: string) => { const parts=token.split("."); if(parts.length!==3) throw new Error("Invalid token"); const data=`${parts[0]}.${parts[1]}`; const sig=crypto.createHmac("sha256",JWT_SECRET).update(data).digest(); const supplied=Buffer.from(parts[2],"base64url"); if(sig.length!==supplied.length || !crypto.timingSafeEqual(sig,supplied)) throw new Error("Invalid token"); const payload=JSON.parse(Buffer.from(parts[1],"base64url").toString()); if(payload.exp < Date.now()/1000) throw new Error("Session expired"); return payload; };
// Seed a local demo family owner on first run. Change the password after demonstrating the prototype.
if (!(db.prepare("SELECT id FROM family_members LIMIT 1").get())) db.prepare("INSERT INTO family_members(name,email,password_hash,role) VALUES(?,?,?,?)").run("Home Owner","owner@weekwok.local",hashPassword(process.env.DEMO_PASSWORD || "WeekWok@123"),"owner");
app.get("/api/health", (_req,res)=>res.json({status:"ok", service:"WeekWok API"}));
app.get("/api/openapi.json", (_req,res)=>res.json({openapi:"3.0.3",info:{title:"WeekWok Pantry Planner API",version:"2.1.0"},servers:[{url:"/api"}],paths:{"/health":{get:{summary:"Health check",responses:{"200":{description:"API is healthy"}}}},"/auth/login":{post:{summary:"Sign in a family member",responses:{"200":{description:"JWT session"},"401":{description:"Invalid credentials"}}}},"/auth/family":{post:{summary:"Create a family member account",responses:{"201":{description:"Created"},"409":{description:"Email already exists"}}}},"/dashboard":{get:{summary:"Get dashboard and planner data",security:[{bearerAuth:[]}] ,responses:{"200":{description:"Dashboard data"}}}},"/pantry":{get:{summary:"List pantry stock",security:[{bearerAuth:[]}]} ,post:{summary:"Add pantry stock",security:[{bearerAuth:[]}] }},"/recipes":{get:{summary:"List recipes",security:[{bearerAuth:[]}]},post:{summary:"Create recipe",security:[{bearerAuth:[]}] }},"/plan/{day}/{meal}":{put:{summary:"Assign a meal",security:[{bearerAuth:[]}]},delete:{summary:"Remove a meal",security:[{bearerAuth:[]}] }},"/grocery":{post:{summary:"Add a manual grocery item",security:[{bearerAuth:[]}]}}},components:{securitySchemes:{bearerAuth:{type:"http",scheme:"bearer",bearerFormat:"JWT"}}}}));
app.post("/api/auth/login", (req,res)=>{ const parsed=z.object({email:z.string().email(),password:z.string().min(8)}).safeParse(req.body); if(!parsed.success) return res.status(400).json({error:"Enter a valid email and password (8+ characters)"}); const member=db.prepare("SELECT id,name,email,password_hash,role FROM family_members WHERE email=?").get(parsed.data.email) as any; if(!member || !verifyPassword(parsed.data.password,member.password_hash)) return res.status(401).json({error:"Email or password is incorrect"}); const user={id:member.id,name:member.name,email:member.email,role:member.role}; res.json({token:signToken(user),user}); });
app.post("/api/auth/family", (req,res)=>{ try { const header=req.headers.authorization||""; if(!header.startsWith("Bearer ")) return res.status(401).json({error:"Owner sign-in is required to add family members"}); const owner=verifyToken(header.slice(7)); if(owner.role!=="owner") return res.status(403).json({error:"Only the household owner can add family members"}); const p=z.object({name:z.string().trim().min(2).max(60),email:z.string().email(),password:z.string().min(8).max(100)}).parse(req.body); const r=db.prepare("INSERT INTO family_members(name,email,password_hash,role) VALUES(?,?,?,?)").run(p.name,p.email,hashPassword(p.password),"member"); const user={id:Number(r.lastInsertRowid),name:p.name,email:p.email,role:"member"}; res.status(201).json({token:signToken(user),user}); } catch(e) { if(String((e as any)?.code)==="SQLITE_CONSTRAINT_UNIQUE") return res.status(409).json({error:"That email is already registered"}); res.status(400).json({error:"Could not create family account"}); } });
app.use("/api", (req,res,next)=>{ if(req.path==="/health" || req.path==="/auth/login" || req.path==="/auth/family") return next(); const header=req.headers.authorization||""; if(!header.startsWith("Bearer ")) return res.status(401).json({error:"Please sign in to continue"}); try { (req as any).user=verifyToken(header.slice(7)); next(); } catch { return res.status(401).json({error:"Your session expired. Please sign in again."}); } });
app.get("/api/dashboard", (_req,res)=> {
 const data=plannerData();
 res.json({ ...data, stats:{planned:data.plan.length,total:21,pantry:data.pantry.length,low:data.pantry.filter((p:any)=>p.quantity<=p.threshold).length,
  grocery:data.grocery.filter((g:any)=>!g.checked).length,estimatedCost:data.grocery.reduce((s:number,g:any)=>s+(g.price_estimate||0),0)}});
});
app.get("/api/pantry", (_req,res)=>res.json(db.prepare("SELECT * FROM pantry_items ORDER BY name").all()));
const pantrySchema=z.object({name:z.string().trim().min(2).max(60),quantity:z.number().finite().min(0).max(1000000),unit:z.enum(["g","kg","ml","l","pcs"]),threshold:z.number().finite().min(0).max(1000000),expiry_date:z.string().nullable().optional(),price_per_unit:z.number().finite().min(0).max(100000),emoji:z.string().max(8).optional()});
app.post("/api/pantry", (req,res,next)=>{try{
 const p=pantrySchema.parse(req.body);
 const factors:any={kg:1000,l:1000,g:1,ml:1,pcs:1};
 const normalizedUnit = p.unit==="kg"?"g":p.unit==="l"?"ml":p.unit;
 const quantity=p.quantity*factors[p.unit], threshold=p.threshold*factors[p.unit];
 const result=db.prepare(`INSERT INTO pantry_items(name,quantity,unit,threshold,expiry_date,price_per_unit,emoji) VALUES(?,?,?,?,?,?,?)`)
  .run(p.name,quantity,normalizedUnit,threshold,p.expiry_date??null,p.price_per_unit,p.emoji??"🥬");
 res.status(201).json(db.prepare("SELECT * FROM pantry_items WHERE id=?").get(result.lastInsertRowid));
 }catch(e){next(e)}});
app.patch("/api/pantry/:id", (req,res,next)=>{try{
 const schema=z.object({quantity:z.number().finite().min(0).max(1000000).optional(),threshold:z.number().finite().min(0).optional(),expiry_date:z.string().nullable().optional()});
 const p=schema.parse(req.body);
 const current=db.prepare("SELECT * FROM pantry_items WHERE id=?").get(Number(req.params.id)) as any;
 if(!current)return res.status(404).json({error:"Pantry item not found"});
 db.prepare("UPDATE pantry_items SET quantity=COALESCE(?,quantity),threshold=COALESCE(?,threshold),expiry_date=COALESCE(?,expiry_date) WHERE id=?").run(p.quantity,p.threshold,p.expiry_date,Number(req.params.id));
 res.json(db.prepare("SELECT * FROM pantry_items WHERE id=?").get(Number(req.params.id)));
 }catch(e){next(e)}});
app.delete("/api/pantry/:id",(req,res)=>{const r=db.prepare("DELETE FROM pantry_items WHERE id=?").run(Number(req.params.id)); r.changes?res.status(204).end():res.status(404).json({error:"Not found"})});
app.get("/api/recipes",(_req,res)=>res.json(plannerData().recipes));
app.post("/api/recipes",(req,res,next)=>{try{
 const schema=z.object({name:z.string().trim().min(2).max(80),category:z.enum(["breakfast","lunch","dinner"]),emoji:z.string().max(8).default("🍲"),prep_minutes:z.number().int().min(1).max(600),servings:z.number().int().min(1).max(30),instructions:z.string().max(1000).default(""),ingredients:z.array(z.object({name:z.string().trim().min(2),quantity:z.number().positive(),unit:z.enum(["g","kg","ml","l","pcs"])})).min(1)});
 const p=schema.parse(req.body);
 const tx=db.transaction(()=>{const r=db.prepare("INSERT INTO recipes(name,category,emoji,prep_minutes,servings,instructions) VALUES(?,?,?,?,?,?)").run(p.name,p.category,p.emoji,p.prep_minutes,p.servings,p.instructions);
 const add=db.prepare("INSERT INTO recipe_ingredients(recipe_id,ingredient_name,quantity,unit) VALUES(?,?,?,?)");p.ingredients.forEach(i=>{const f:any={kg:1000,l:1000,g:1,ml:1,pcs:1};const u=i.unit==="kg"?"g":i.unit==="l"?"ml":i.unit;add.run(r.lastInsertRowid,i.name,i.quantity*f[i.unit],u)});return r.lastInsertRowid;});
 res.status(201).json(plannerData().recipes.find((x:any)=>x.id===Number(tx())));
 }catch(e){next(e)}});
app.get("/api/plan",(_req,res)=>res.json(db.prepare("SELECT * FROM meal_schedules ORDER BY day_index").all()));
app.put("/api/plan/:day/:meal",(req,res,next)=>{try{
 const day=z.coerce.number().int().min(0).max(6).parse(req.params.day);
 const meal=z.enum(["breakfast","lunch","dinner"]).parse(req.params.meal);
 const recipeId=z.number().int().positive().parse(req.body.recipe_id);
 if(!db.prepare("SELECT id FROM recipes WHERE id=?").get(recipeId))return res.status(404).json({error:"Recipe not found"});
 db.prepare(`INSERT INTO meal_schedules(day_index,meal_type,recipe_id) VALUES(?,?,?)
 ON CONFLICT(day_index,meal_type) DO UPDATE SET recipe_id=excluded.recipe_id`).run(day,meal,recipeId);
 res.json(plannerData());
 }catch(e){next(e)}});
app.delete("/api/plan/:day/:meal",(req,res,next)=>{try{
 const day=z.coerce.number().int().min(0).max(6).parse(req.params.day);
 const meal=z.enum(["breakfast","lunch","dinner"]).parse(req.params.meal);
 db.prepare("DELETE FROM meal_schedules WHERE day_index=? AND meal_type=?").run(day,meal);
 res.json(plannerData());
 }catch(e){next(e)}});
app.post("/api/grocery",(req,res,next)=>{try{
 const p=z.object({name:z.string().trim().min(2).max(80),quantity:z.number().positive().max(100000),unit:z.enum(["g","ml","pcs"]),price_estimate:z.number().min(0).default(0)}).parse(req.body);
 const r=db.prepare("INSERT INTO grocery_items(name,quantity,unit,price_estimate) VALUES(?,?,?,?)").run(p.name,p.quantity,p.unit,p.price_estimate);
 res.status(201).json(db.prepare("SELECT * FROM grocery_items WHERE id=?").get(r.lastInsertRowid));
 }catch(e){next(e)}});
app.patch("/api/grocery/:id",(req,res,next)=>{try{
 const checked=z.boolean().parse(req.body.checked);
 const id=Number(req.params.id);
 const r=db.prepare("UPDATE grocery_items SET checked=? WHERE id=? AND source='manual'").run(checked?1:0,id);
 if(!r.changes)return res.status(404).json({error:"Manual grocery item not found"});
 res.json(db.prepare("SELECT * FROM grocery_items WHERE id=?").get(id));
 }catch(e){next(e)}});
app.delete("/api/grocery/:id",(req,res)=>{const r=db.prepare("DELETE FROM grocery_items WHERE id=? AND source='manual'").run(Number(req.params.id));r.changes?res.status(204).end():res.status(404).json({error:"Manual item not found"})});
app.use((err:any,_req:express.Request,res:express.Response,_next:express.NextFunction)=>{
 if(err instanceof z.ZodError)return res.status(400).json({error:"Validation failed",details:err.issues.map(i=>`${i.path.join(".")}: ${i.message}`)});
 if(String(err?.code)==="SQLITE_CONSTRAINT_UNIQUE")return res.status(409).json({error:"An item with this name already exists"});
 if(err instanceof Error && err.message.includes("Unit mismatch"))return res.status(400).json({error:err.message});
 process.stderr.write(JSON.stringify({level:"error",time:new Date().toISOString(),message:err instanceof Error?err.message:"Unknown error",path:_req.path})+"\n");res.status(500).json({error:"Internal server error"});
});
app.listen(PORT,()=>process.stdout.write(JSON.stringify({level:"info",time:new Date().toISOString(),message:"WeekWok API started",port:PORT})+"\n"));
