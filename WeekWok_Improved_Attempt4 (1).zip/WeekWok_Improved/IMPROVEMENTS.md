# WeekWok — Attempt 4 improvement notes

This package builds on the supplied Attempt 3 ZIP and targets the gaps named in the evaluation report (pages 3–4).

## Changes made

1. **Family authentication:** added sign-in, owner-created family-member accounts, scrypt password hashing, signed 12-hour HS256 bearer sessions, protected application API routes, and a sign-out control.
2. **Unit normalization:** compatible mass and volume inputs are converted to canonical units (`kg` → `g`, `l` → `ml`) before inventory deficit calculations. Incompatible dimensions are still rejected.
3. **Database query support:** added indexes for meal schedules, recipe ingredients, grocery status/source, and pantry expiry dates.
4. **Operational visibility:** added structured JSON startup/error logs and an OpenAPI 3.0 JSON endpoint at `/api/openapi.json`.
5. **Documentation:** updated setup, authentication, API, and known-limitations instructions; added additional unit tests.

## Evaluation report mapping

| Report feedback | Package response |
|---|---|
| Authentication missing for Family Members | Family sign-in and owner-authorized member creation added |
| Unit mismatches rejected instead of converted | kg/g and l/ml normalization added |
| No structured logging | JSON startup and error events added |
| No API documentation | OpenAPI 3.0 JSON endpoint added |
| SQLite query/index scalability | Supporting indexes added |
| Migration tool suggested | Schema still uses idempotent SQLite `CREATE TABLE IF NOT EXISTS`; a versioned migration framework remains future work |
| Multi-tenancy / production readiness | Accounts share the demo household database; strict tenant isolation, invitations, password reset, and live sync remain future work |

## Demo credentials

- Email: `owner@weekwok.local`
- Password: `WeekWok@123`

The owner is seeded only on a fresh database. Set a different `DEMO_PASSWORD` before the first run if desired. Set a persistent random `JWT_SECRET` in the project-root `.env` file. Do not use demo credentials or the fallback secret for a public deployment.

## Verification performed

- TypeScript strict compilation of the pure inventory logic module completed successfully.
- Node smoke checks passed for kg normalization, mixed kg/g aggregation, deficit calculation, and incompatible-dimension rejection.
- Full workspace install/build and integration tests could not be completed in this environment because dependency installation did not finish. Run the commands below on the target machine after `npm install`.

```bash
npm install
npm run typecheck
npm test
npm run build
npm run dev
```

A target grade cannot be guaranteed: the evaluator's score depends on running the project and checking its full rubric. This is an improved academic prototype, not a claim of production certification.
